<?php $__env->startSection('page_title', 'Viral Load Results'); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/clinical-pages.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="clinical-page">
    <header class="clinical-page-header">
        <div><h2>Viral Load Results</h2><p>View, filter, and manage patient viral load test results.</p></div>
        <div class="clinical-page-actions">
            <a href="<?php echo e(route('reports.viral_load.excel')); ?>" class="clinical-btn">Export Excel</a>
            <a href="<?php echo e(route('reports.viral_load.pdf')); ?>" class="clinical-btn clinical-btn-danger">Export PDF</a>
            <?php if(in_array(auth()->user()->role, ['Administrator','Lab Technician'])): ?>
                <a href="/viral-load/create" class="clinical-btn clinical-btn-primary"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>Add Result</a>
            <?php endif; ?>
        </div>
    </header>

    <form method="GET" action="/viral-load" class="clinical-card clinical-toolbar">
        <div class="clinical-field clinical-search"><label for="vl_search">Search</label><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><input id="vl_search" name="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="Search patient, ART number or result ID..."></div>
        <div class="clinical-field"><label for="vl_status">Result Status</label><select id="vl_status" name="status" class="form-select"><option value="">All statuses</option><option value="suppressed" <?php if(request('status') === 'suppressed'): echo 'selected'; endif; ?>>Suppressed</option><option value="high" <?php if(request('status') === 'high'): echo 'selected'; endif; ?>>High Viral Load</option></select></div>
        <div class="clinical-field"><label for="from_date">From Date</label><input id="from_date" type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" class="form-control"></div>
        <div class="clinical-field"><label for="to_date">To Date</label><input id="to_date" type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" class="form-control"></div>
        <div class="clinical-toolbar-actions"><button class="clinical-btn clinical-btn-primary">Apply</button><a href="/viral-load" class="clinical-btn">Reset</a></div>
    </form>

    <section class="clinical-card clinical-table-card">
        <div class="clinical-table-meta"><strong>Viral Load Register</strong><span>Showing <?php echo e($results->firstItem() ?? 0); ?>–<?php echo e($results->lastItem() ?? 0); ?> of <?php echo e($results->total()); ?></span></div>
        <div class="table-responsive">
            <table class="table clinical-table">
                <thead><tr><th>Result ID</th><th>ART Number</th><th>Patient</th><th>Sample Date</th><th>Result Date</th><th>Result (cp/ml)</th><th>Log</th><th>Status</th><th>Lab</th><th>Service Actions</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="primary-cell">VL-<?php echo e(str_pad($row->vl_id, 5, '0', STR_PAD_LEFT)); ?></td>
                        <td><?php echo e($row->patient?->art_number ?: '—'); ?></td>
                        <td class="primary-cell"><?php echo e($row->patient?->first_name); ?> <?php echo e($row->patient?->last_name); ?></td>
                        <td><?php echo e($row->sample_date ? \Illuminate\Support\Carbon::parse($row->sample_date)->format('d M Y') : '—'); ?></td>
                        <td><?php echo e($row->result_date ? \Illuminate\Support\Carbon::parse($row->result_date)->format('d M Y') : '—'); ?></td>
                        <td class="primary-cell"><?php echo e($row->result_cpml !== null ? number_format((float) $row->result_cpml, 2) : '—'); ?></td>
                        <td><?php echo e($row->result_log !== null ? number_format((float) $row->result_log, 2) : '—'); ?></td>
                        <td><?php if((float) $row->result_cpml >= 1000): ?><span class="clinical-badge clinical-badge-danger">High VL</span><?php else: ?><span class="clinical-badge clinical-badge-success">Suppressed</span><?php endif; ?></td>
                        <td><?php echo e($row->lab ?: '—'); ?></td>
                        <td>
                            <div class="clinical-row-actions">
                                <?php ($printPayment = $row->payments->where('payment_type', 'result_print')->sortByDesc('payment_id')->first()); ?>
                                <?php if(!in_array($row->vl_id, $latestResultIds, true)): ?>
                                    <span class="clinical-badge clinical-badge-neutral">Historical</span>
                                <?php elseif(in_array(auth()->user()->role, ['Administrator','Clinician','Lab Technician'])): ?>
                                    <?php if($printPayment?->status === 'paid'): ?>
                                        <a href="<?php echo e(route('patients.results.print', $row->patient_id)); ?>" class="clinical-btn">Print</a>
                                    <?php elseif($printPayment?->status === 'pending'): ?>
                                        <span class="clinical-badge clinical-badge-warning">Awaiting Reception</span>
                                    <?php else: ?>
                                        <form method="POST" action="<?php echo e(route('payments.request')); ?>"><?php echo csrf_field(); ?><input type="hidden" name="patient_id" value="<?php echo e($row->patient_id); ?>"><input type="hidden" name="vl_id" value="<?php echo e($row->vl_id); ?>"><input type="hidden" name="payment_type" value="result_print"><button class="clinical-btn" type="submit">Request Print</button></form>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if(in_array(auth()->user()->role, ['Administrator','Clinician'])): ?>
                                    <button
                                        type="button"
                                        class="clinical-btn"
                                        data-sms-action="<?php echo e(route('sms.viral_load.send_result', $row->vl_id)); ?>"
                                        data-sms-title="Viral Load Result SMS"
                                        data-sms-hint="Verify the recipient number and edit the viral load result message if needed."
                                        data-sms-phone="<?php echo e($row->patient?->phone); ?>"
                                        data-sms-message="<?php echo e(app(\App\Services\NotificationService::class)->buildViralLoadResultMessage($row)); ?>"
                                    >Send SMS</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="10" class="clinical-table-empty">No viral load results match the selected filters.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="clinical-pagination"><?php echo e($results->links()); ?></div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/viral_load/index.blade.php ENDPATH**/ ?>