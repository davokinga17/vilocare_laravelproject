<?php $__env->startSection('page_title', 'EAC Sessions'); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/clinical-pages.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="clinical-page">
    <header class="clinical-page-header">
        <div><h2>EAC Sessions</h2><p>Track enhanced adherence counselling sessions and follow-up progress.</p></div>
        <div class="clinical-page-actions"><button type="button" class="clinical-btn" onclick="window.print()"><svg viewBox="0 0 24 24"><path d="M12 3v12M7 8l5-5 5 5M5 13v7h14v-7"/></svg>Export</button></div>
    </header>

    <section class="clinical-metrics">
        <article class="clinical-metric"><span class="clinical-metric-icon">AC</span><div><span>Active EAC Clients</span><strong><?php echo e(number_format($metrics['active_clients'])); ?></strong><small>clients</small></div></article>
        <article class="clinical-metric"><span class="clinical-metric-icon">S1</span><div><span>Session 1 Due</span><strong><?php echo e(number_format($metrics['session_one_due'])); ?></strong><small>sessions</small></div></article>
        <article class="clinical-metric"><span class="clinical-metric-icon">PR</span><div><span>Pending Review</span><strong><?php echo e(number_format($metrics['pending'])); ?></strong><small>sessions</small></div></article>
        <article class="clinical-metric"><span class="clinical-metric-icon">OK</span><div><span>Completed</span><strong><?php echo e(number_format($metrics['completed'])); ?></strong><small>sessions</small></div></article>
    </section>

    <form method="GET" action="<?php echo e(route('eac.index')); ?>" class="clinical-card clinical-toolbar">
        <div class="clinical-field clinical-search"><label for="eac_search">Search Patient</label><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><input id="eac_search" name="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="Search by patient name or ART number..."></div>
        <div class="clinical-field"><label for="session_number">Session Number</label><select id="session_number" name="session_number" class="form-select"><option value="">All sessions</option><?php $__currentLoopData = range(1,3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($number); ?>" <?php if((string) request('session_number') === (string) $number): echo 'selected'; endif; ?>>Session <?php echo e($number); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="clinical-field"><label for="eac_status">Status</label><select id="eac_status" name="status" class="form-select"><option value="">All statuses</option><?php $__currentLoopData = ['Pending','Ongoing','Completed','Missed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="clinical-field"><label>Date Range</label><div class="clinical-date-pair"><input type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" class="form-control" aria-label="From date"><input type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" class="form-control" aria-label="To date"></div></div>
        <div class="clinical-toolbar-actions"><button class="clinical-btn clinical-btn-primary" type="submit">Filter</button><a href="<?php echo e(route('eac.index')); ?>" class="clinical-btn">Reset</a></div>
    </form>

    <section class="clinical-card clinical-table-card">
        <div class="clinical-table-meta"><strong>EAC Session Register</strong><span>Showing <?php echo e($sessions->firstItem() ?? 0); ?>–<?php echo e($sessions->lastItem() ?? 0); ?> of <?php echo e($sessions->total()); ?></span></div>
        <div class="table-responsive">
            <table class="table clinical-table">
                <thead><tr><th>Patient</th><th>ART No.</th><th>Session</th><th>Session Date</th><th>Assigned Clinician</th><th>Status</th><th>Outcome / Next Step</th><th>Payment / Approval</th><th>SMS Reminder</th><th>Actions</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="primary-cell"><?php echo e($session->patient?->first_name); ?> <?php echo e($session->patient?->last_name); ?><span class="secondary-line"><?php echo e($session->patient?->sex ?: '—'); ?><?php echo e($session->patient?->age ? ', '.$session->patient->age.' years' : ''); ?></span></td>
                        <td><?php echo e($session->patient?->art_number ?: '—'); ?></td>
                        <td class="primary-cell"><?php echo e($session->session_number); ?></td>
                        <td><?php echo e(optional($session->session_date)->format('d M Y') ?: 'Not scheduled'); ?></td>
                        <td><?php echo e($session->counselor ?: 'Not assigned'); ?></td>
                        <td>
                            <?php if($session->session_number === 3 && $session->completion_status === 'Completed'): ?>
                                <span class="clinical-badge clinical-badge-warning">Repeat VL Required</span>
                            <?php else: ?>
                                <span class="clinical-badge <?php echo e($session->completion_status === 'Completed' ? 'clinical-badge-success' : ($session->completion_status === 'Missed' ? 'clinical-badge-danger' : 'clinical-badge-warning')); ?>"><?php echo e($session->completion_status); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($session->action_plan ?: $session->notes ?: 'Adherence counselling'); ?><span class="secondary-line"><?php if($session->next_session_date): ?>Next: <?php echo e(optional($session->next_session_date)->format('d M Y')); ?><?php elseif($session->session_number < 3 && $session->completion_status === 'Completed'): ?>Next: Session <?php echo e($session->session_number + 1); ?><?php else: ?><?php echo e($session->completion_status === 'Completed' ? 'Follow-up as indicated' : 'Awaiting session completion'); ?><?php endif; ?></span></td>
                        <td>
                            <?php if($session->hasPaidConsultationFee()): ?>
                                <span class="clinical-badge clinical-badge-success">Reception Approved</span>
                            <?php elseif($session->hasPendingConsultationFee()): ?>
                                <span class="clinical-badge clinical-badge-warning">Pending Reception</span>
                            <?php else: ?>
                                <form method="POST" action="<?php echo e(route('payments.request')); ?>"><?php echo csrf_field(); ?><input type="hidden" name="patient_id" value="<?php echo e($session->patient_id); ?>"><input type="hidden" name="eac_id" value="<?php echo e($session->eac_id); ?>"><input type="hidden" name="payment_type" value="eac_consultation"><button type="submit" class="clinical-btn">Request Payment</button></form>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($session->completion_status === 'Pending'): ?>
                                <button
                                    type="button"
                                    class="clinical-btn"
                                    data-sms-action="<?php echo e(route('sms.eac.send_reminder', $session->eac_id)); ?>"
                                    data-sms-title="EAC Reminder SMS"
                                    data-sms-hint="Verify the phone number and customize the EAC follow-up reminder before sending."
                                    data-sms-phone="<?php echo e($session->patient?->phone); ?>"
                                    data-sms-message="<?php echo e(app(\App\Services\NotificationService::class)->buildDueEacReminderMessage($session->patient, $session)); ?>"
                                >Send SMS</button>
                            <?php elseif($session->session_number === 3 && $session->completion_status === 'Completed'): ?>
                                <button
                                    type="button"
                                    class="clinical-btn"
                                    data-sms-action="<?php echo e(route('sms.vl_due.send_reminder', $session->eac_id)); ?>"
                                    data-sms-title="Repeat VL Reminder SMS"
                                    data-sms-hint="Confirm the patient's number and tailor the repeat viral load reminder before sending."
                                    data-sms-phone="<?php echo e($session->patient?->phone); ?>"
                                    data-sms-message="<?php echo e(app(\App\Services\NotificationService::class)->buildDueVlReminderMessage($session->patient, $session->next_session_date ?: $session->session_date)); ?>"
                                >Send VL SMS</button>
                            <?php else: ?><span class="clinical-badge clinical-badge-neutral">Not needed</span><?php endif; ?>
                        </td>
                        <td>
                            <?php if($session->completion_status === 'Pending' && $session->hasPaidConsultationFee()): ?>
                                <form method="POST" action="<?php echo e(route('eac.complete', $session->eac_id)); ?>" onsubmit="return confirm('Mark this EAC session complete?')"><?php echo csrf_field(); ?><button type="submit" class="clinical-btn clinical-btn-primary">Complete</button></form>
                            <?php elseif($session->completion_status === 'Pending'): ?>
                                <span class="clinical-badge clinical-badge-neutral">Payment locked</span>
                            <?php else: ?><span class="clinical-badge clinical-badge-success">Done</span><?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="10" class="clinical-table-empty">No EAC sessions match the selected filters.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="clinical-pagination"><?php echo e($sessions->links()); ?></div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/eac/index.blade.php ENDPATH**/ ?>