<?php $__env->startSection('page_title', 'Patients'); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/clinical-pages.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="clinical-page">
    <?php ($facilityLabels = collect($facilities)->pluck('label', 'value')); ?>
    <header class="clinical-page-header">
        <div>
            <h2>Patients</h2>
            <p>Manage and view all patients enrolled in ViLoCare.</p>
        </div>
        <div class="clinical-page-actions">
            <a href="<?php echo e(route('reports.index')); ?>" class="clinical-btn">View Reports</a>
            <a href="<?php echo e(route('patients.create')); ?>" class="clinical-btn clinical-btn-primary">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
                Add Patient
            </a>
        </div>
    </header>

    <?php if(session('import_errors')): ?>
        <div class="alert alert-warning">
            <strong>Import notes:</strong>
            <ul class="mb-0 mt-1">
                <?php $__currentLoopData = session('import_errors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $importError): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($importError); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <section class="clinical-card clinical-import">
        <div class="clinical-import-copy">
            <strong>Bulk patient upload</strong>
            <span>Import Excel or CSV records using the approved patient template.</span>
        </div>
        <form method="POST" action="<?php echo e(route('patients.import')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" name="patients_file" class="form-control" accept=".csv,.txt,.xlsx,.xls" required>
            <button class="clinical-btn" type="submit">Upload Patients</button>
        </form>
    </section>

    <form method="GET" action="<?php echo e(route('patients.index')); ?>" class="clinical-card clinical-toolbar">
        <div class="clinical-field clinical-search">
            <label for="patient_search">Search</label>
            <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
            <input id="patient_search" type="text" name="search" class="form-control" placeholder="Search by ART number, name or phone..." value="<?php echo e(request('search')); ?>">
        </div>
        <div class="clinical-field">
            <label for="patient_sex">Sex</label>
            <select id="patient_sex" name="sex" class="form-select">
                <option value="">All Sex</option>
                <option value="Male" <?php if(request('sex') === 'Male'): echo 'selected'; endif; ?>>Male</option>
                <option value="Female" <?php if(request('sex') === 'Female'): echo 'selected'; endif; ?>>Female</option>
                <option value="Other" <?php if(request('sex') === 'Other'): echo 'selected'; endif; ?>>Other</option>
            </select>
        </div>
        <div class="clinical-field">
            <label for="patient_age">Age</label>
            <input id="patient_age" type="number" name="age" class="form-control" min="0" max="130" placeholder="All ages" value="<?php echo e(request('age')); ?>">
        </div>
        <div class="clinical-field">
            <label for="patient_facility">Facility</label>
            <select id="patient_facility" name="facility_id" class="form-select"><option value="">All facilities</option><?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($facility['value']); ?>" <?php if((string) request('facility_id') === $facility['value']): echo 'selected'; endif; ?>><?php echo e($facility['label']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
        </div>
        <div class="clinical-toolbar-actions">
            <button class="clinical-btn clinical-btn-primary" type="submit">Apply Filters</button>
            <a href="<?php echo e(route('patients.index')); ?>" class="clinical-btn">Reset</a>
        </div>
    </form>

    <section class="clinical-card clinical-table-card">
        <div class="clinical-table-meta">
            <strong>Patient Register</strong>
            <span>Showing <?php echo e($patients->firstItem() ?? 0); ?>–<?php echo e($patients->lastItem() ?? 0); ?> of <?php echo e($patients->total()); ?></span>
        </div>
        <div class="table-responsive">
            <table class="table clinical-table">
                <thead>
                    <tr>
                        <th>ART Number</th>
                        <th>Patient</th>
                        <th>Sex</th>
                        <th>Age</th>
                        <th>Phone</th>
                        <th>Facility</th>
                        <th>Current Regimen</th>
                        <th>ART Start Date</th>
                        <th>Adherence</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="primary-cell"><?php echo e($patient->art_number); ?></td>
                            <td class="primary-cell"><?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?></td>
                            <td><?php echo e($patient->sex ?: '—'); ?></td>
                            <td><?php echo e($patient->age ?? '—'); ?></td>
                            <td><?php echo e($patient->phone ?: '—'); ?></td>
                            <td><?php echo e($facilityLabels->get((string) $patient->facility_id, '—')); ?></td>
                            <td><?php echo e($patient->current_regimen ?: 'Not recorded'); ?></td>
                            <td><?php echo e(optional($patient->art_start_date)->format('d M Y') ?: '—'); ?></td>
                            <td>
                                <?php ($adherence = strtolower((string) $patient->arv_adherence)); ?>
                                <span class="clinical-badge <?php echo e($adherence === 'good' ? 'clinical-badge-success' : ($adherence === 'poor' ? 'clinical-badge-danger' : 'clinical-badge-warning')); ?>">
                                    <?php echo e($patient->arv_adherence ?: 'Not set'); ?>

                                </span>
                            </td>
                            <td>
                                <div class="clinical-row-actions">
                                    <a href="<?php echo e(route('patients.show', $patient->patient_id)); ?>" class="clinical-icon-btn" title="View patient" aria-label="View patient">
                                        <svg viewBox="0 0 24 24"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg>
                                    </a>
                                    <a href="<?php echo e(route('patients.edit', $patient->patient_id)); ?>" class="clinical-icon-btn" title="Edit patient" aria-label="Edit patient">
                                        <svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg>
                                    </a>
                                    <form action="<?php echo e(route('patients.destroy', $patient->patient_id)); ?>" method="POST" onsubmit="return confirm('Delete this patient?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="clinical-icon-btn danger" type="submit" title="Delete patient" aria-label="Delete patient">
                                            <svg viewBox="0 0 24 24"><path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v5M14 11v5"/></svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="10" class="clinical-table-empty">No patients match the selected filters.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="clinical-pagination"><?php echo e($patients->links()); ?></div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/patients/index.blade.php ENDPATH**/ ?>