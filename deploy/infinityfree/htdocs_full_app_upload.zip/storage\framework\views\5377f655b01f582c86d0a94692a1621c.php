<?php $__env->startSection('page_title', 'Samples'); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/clinical-pages.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="clinical-page">
    <header class="clinical-page-header">
        <div><h2>Sample Management</h2><p>Track collected samples, reception status, and quality rejections.</p></div>
        <a href="<?php echo e(route('samples.create')); ?>" class="clinical-btn clinical-btn-primary"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>Add Sample</a>
    </header>

    <?php if($errors->any()): ?><div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>

    <form method="GET" action="<?php echo e(route('samples.index')); ?>" class="clinical-card clinical-toolbar compact-four">
        <div class="clinical-field clinical-search"><label for="sample_search">Search</label><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><input id="sample_search" name="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="Search by sample, ART number or patient..."></div>
        <div class="clinical-field"><label for="sample_status">Status</label><select id="sample_status" name="status" class="form-select"><option value="">All statuses</option><?php $__currentLoopData = ['Collected','Received','Rejected','Processed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="clinical-field"><label for="sample_type">Sample Type</label><select id="sample_type" name="sample_type" class="form-select"><option value="">All types</option><?php $__currentLoopData = $sampleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($type); ?>" <?php if(request('sample_type') === $type): echo 'selected'; endif; ?>><?php echo e($type); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="clinical-toolbar-actions"><button class="clinical-btn clinical-btn-primary">Apply Filters</button><a href="<?php echo e(route('samples.index')); ?>" class="clinical-btn">Reset</a></div>
    </form>

    <div class="clinical-split">
        <section class="clinical-card clinical-table-card">
            <div class="clinical-table-meta"><strong>Sample Collection Register</strong><span><?php echo e($samples->total()); ?> record(s)</span></div>
            <div class="table-responsive">
                <table class="table clinical-table">
                    <thead><tr><th>Sample ID</th><th>Patient</th><th>Collection</th><th>Type</th><th>Collector</th><th>Status</th><th>Reception</th><th>Facility</th><th>Quality</th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $samples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sample): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="primary-cell">SMP-<?php echo e(str_pad($sample->sample_id, 5, '0', STR_PAD_LEFT)); ?></td>
                            <td class="primary-cell"><?php echo e(optional($sample->patient)->first_name); ?> <?php echo e(optional($sample->patient)->last_name); ?><span class="secondary-line"><?php echo e(optional($sample->patient)->art_number); ?></span></td>
                            <td><?php echo e(optional($sample->collection_date)->format('d M Y') ?: '—'); ?></td>
                            <td><?php echo e($sample->sample_type ?: '—'); ?></td>
                            <td><?php echo e($sample->collector ?: '—'); ?></td>
                            <td><span class="clinical-badge <?php echo e($sample->status === 'Rejected' ? 'clinical-badge-danger' : ($sample->status === 'Processed' ? 'clinical-badge-success' : 'clinical-badge-neutral')); ?>"><?php echo e($sample->status ?: 'Collected'); ?></span></td>
                            <td><?php echo e(optional($sample->sample_reception_date)->format('d M Y') ?: '—'); ?></td>
                            <td><?php echo e($sample->health_facility_code ?: '—'); ?></td>
                            <td><?php if($sample->rejections->isNotEmpty()): ?><span class="clinical-badge clinical-badge-danger">Rejected</span><?php else: ?><span class="clinical-badge clinical-badge-success">Accepted</span><?php endif; ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="9" class="clinical-table-empty">No sample records match the selected filters.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="clinical-pagination"><?php echo e($samples->links()); ?></div>
        </section>

        <aside class="clinical-card clinical-side-card">
            <h3>Record Sample Rejection</h3>
            <form method="POST" action="<?php echo e(route('samples.reject')); ?>" class="d-grid gap-2">
                <?php echo csrf_field(); ?>
                <div class="clinical-field"><label>Sample <span class="required">*</span></label><select name="sample_id" class="form-select" required><option value="">Select sample</option><?php $__currentLoopData = $rejectableSamples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sample): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($sample->sample_id); ?>">SMP-<?php echo e(str_pad($sample->sample_id, 5, '0', STR_PAD_LEFT)); ?> · <?php echo e(optional($sample->patient)->art_number); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="clinical-field"><label>Rejection Date</label><input type="date" name="rejection_date" value="<?php echo e(old('rejection_date', now()->toDateString())); ?>" class="form-control"></div>
                <div class="clinical-field"><label>Reason</label><textarea name="reason" class="form-control" rows="2" placeholder="State the rejection reason"><?php echo e(old('reason')); ?></textarea></div>
                <div class="clinical-field"><label>Action Taken</label><textarea name="action_taken" class="form-control" rows="2"><?php echo e(old('action_taken')); ?></textarea></div>
                <div class="clinical-field"><label>Corrective Action</label><textarea name="corrective_action" class="form-control" rows="2"><?php echo e(old('corrective_action')); ?></textarea></div>
                <button class="clinical-btn clinical-btn-danger" type="submit">Save Rejection</button>
            </form>
        </aside>
    </div>

    <section class="clinical-card clinical-table-card">
        <div class="clinical-table-meta"><strong>Recent Sample Rejections</strong><span>Latest quality events</span></div>
        <div class="table-responsive"><table class="table clinical-table"><thead><tr><th>ID</th><th>Sample</th><th>Patient</th><th>Date</th><th>Reason</th><th>Action Taken</th><th>Corrective Action</th></tr></thead><tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rejections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rejection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td class="primary-cell">REJ-<?php echo e(str_pad($rejection->rejection_id, 4, '0', STR_PAD_LEFT)); ?></td><td>SMP-<?php echo e(str_pad($rejection->sample_id, 5, '0', STR_PAD_LEFT)); ?></td><td><?php echo e(optional(optional($rejection->sample)->patient)->art_number); ?> · <?php echo e(optional(optional($rejection->sample)->patient)->first_name); ?> <?php echo e(optional(optional($rejection->sample)->patient)->last_name); ?></td><td><?php echo e(optional($rejection->rejection_date)->format('d M Y') ?: '—'); ?></td><td><?php echo e($rejection->reason ?: '—'); ?></td><td><?php echo e($rejection->action_taken ?: '—'); ?></td><td><?php echo e($rejection->corrective_action ?: '—'); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="7" class="clinical-table-empty">No sample rejections recorded.</td></tr><?php endif; ?>
        </tbody></table></div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/samples/index.blade.php ENDPATH**/ ?>