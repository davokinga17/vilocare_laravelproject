<?php if(($notificationCenter['visible'] ?? false) === true): ?>
    <div class="dropdown notification-menu">
        <button
            class="notification-trigger"
            type="button"
            id="globalNotifications"
            data-bs-toggle="dropdown"
            data-bs-auto-close="outside"
            aria-expanded="false"
            aria-label="Open notifications and quick actions"
        >
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
            </svg>
            <?php if(($notificationCenter['recent_notifications'] ?? collect())->isNotEmpty()): ?>
                <span class="notification-count"><?php echo e($notificationCenter['recent_notifications']->count()); ?></span>
            <?php endif; ?>
        </button>

        <div class="dropdown-menu dropdown-menu-end notification-panel" aria-labelledby="globalNotifications">
            <div class="notification-panel-head">
                <div>
                    <span>Activity</span>
                    <h2>Notifications</h2>
                </div>
                <small>Quick access</small>
            </div>

            <div class="notification-quick-actions" role="group" aria-label="Notification quick actions">
                <button type="button" class="notification-action" data-notification-view="sms">
                    <span class="notification-action-icon action-sms">SM</span>
                    <span>SMS</span>
                </button>
                <button type="button" class="notification-action" data-notification-view="reminder">
                    <span class="notification-action-icon action-reminder">RM</span>
                    <span>Reminder</span>
                </button>
            </div>

            <div class="notification-reminder" id="notificationReminder" hidden>
                <form method="POST" action="<?php echo e(route('dashboard.support.reminder')); ?>">
                    <?php echo csrf_field(); ?>
                    <label for="notification_appointment_id">Upcoming appointment</label>
                    <div class="notification-reminder-row">
                        <select id="notification_appointment_id" name="appointment_id" class="form-select form-select-sm">
                            <?php $__empty_1 = true; $__currentLoopData = ($notificationCenter['upcoming_appointments'] ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($appointment->appointment_id); ?>">
                                    <?php echo e(optional($appointment->appointment_date)->format('d M Y')); ?> - <?php echo e(trim(($appointment->patient->first_name ?? '') . ' ' . ($appointment->patient->last_name ?? ''))); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value="">No upcoming appointments</option>
                            <?php endif; ?>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm" <?php if(($notificationCenter['upcoming_appointments'] ?? collect())->isEmpty()): echo 'disabled'; endif; ?>>Send</button>
                    </div>
                </form>
            </div>

            <div class="notification-feed" id="notificationActivity">
                <div class="notification-feed-head">
                    <strong id="notificationFeedTitle">Recent activity</strong>
                    <button type="button" data-notification-view="all" hidden>Show all</button>
                </div>
                <div class="notification-list">
                    <?php $__empty_1 = true; $__currentLoopData = ($notificationCenter['recent_notifications'] ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="notification-item" data-notification-channel="<?php echo e(strtolower($notification->channel)); ?>">
                            <span class="support-icon support-icon-<?php echo e(strtolower($notification->channel)); ?>">
                                <?php echo e(strtoupper(substr($notification->channel, 0, 2))); ?>

                            </span>
                            <div class="notification-item-copy">
                                <strong><?php echo e(ucwords(str_replace('_', ' ', $notification->category))); ?></strong>
                                <span><?php echo e(strtoupper($notification->channel)); ?> to <?php echo e($notification->recipient ?: 'system'); ?></span>
                            </div>
                            <span class="support-status status-<?php echo e(strtolower($notification->status)); ?>"><?php echo e(ucfirst($notification->status)); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="notification-empty">No notification activity yet.</div>
                    <?php endif; ?>
                    <div class="notification-empty" id="notificationSmsEmpty" hidden>No recent SMS activity.</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            var notificationItems = document.querySelectorAll('.notification-item');
            var notificationReminder = document.getElementById('notificationReminder');
            var notificationFeedTitle = document.getElementById('notificationFeedTitle');
            var notificationSmsEmpty = document.getElementById('notificationSmsEmpty');
            var showAllNotifications = document.querySelector('[data-notification-view="all"]');

            document.querySelectorAll('[data-notification-view]').forEach(function (button) {
                button.addEventListener('click', function () {
                    var view = button.getAttribute('data-notification-view');
                    var showReminder = view === 'reminder';
                    var filterSms = view === 'sms';
                    var visibleSmsCount = 0;

                    if (notificationReminder) {
                        notificationReminder.hidden = !showReminder;
                    }

                    notificationItems.forEach(function (item) {
                        var visible = !filterSms || item.getAttribute('data-notification-channel') === 'sms';
                        item.hidden = !visible;
                        visibleSmsCount += filterSms && visible ? 1 : 0;
                    });

                    if (notificationFeedTitle) {
                        notificationFeedTitle.textContent = filterSms ? 'Recent SMS activity' : 'Recent activity';
                    }

                    if (notificationSmsEmpty) {
                        notificationSmsEmpty.hidden = !filterSms || visibleSmsCount > 0;
                    }

                    if (showAllNotifications) {
                        showAllNotifications.hidden = !filterSms;
                    }
                });
            });
        })();
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/partials/notification-center.blade.php ENDPATH**/ ?>