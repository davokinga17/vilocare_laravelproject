﻿<?php
    $role = auth()->user()->role;
?>

<aside class="app-sidebar" id="appSidebar">
    <div class="sidebar-head">
        <div class="sidebar-logo-wrap">
            <span class="sidebar-logo">
                <img src="<?php echo e(asset('images/vilocarelogo.png')); ?>" alt="ViLoCare Logo" />
            </span>
            <div class="sidebar-brand">
                <p class="sidebar-brand-title">ViLoCare</p>
                <p class="sidebar-brand-sub">HIV Viral Load Platform</p>
            </div>
        </div>
    </div>

    <nav class="sidebar-menu">
        <p class="sidebar-section"><?php echo e($role === 'Receptionist' ? 'Reception Desk' : 'Overview'); ?></p>

        <?php if($role !== 'Receptionist'): ?>
            <a href="/dashboard" class="sidebar-link <?php echo e(request()->is('dashboard') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">DB</span>
                Dashboard
            </a>

            <a href="<?php echo e(route('profile.edit')); ?>" class="sidebar-link <?php echo e(request()->is('profile') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">PR</span>
                My Profile
            </a>

            <p class="sidebar-section">Clinical</p>
        <?php endif; ?>

        <?php if(in_array($role, ['Administrator', 'Clinician', 'Data Clerk', 'Data Officer'])): ?>
            <a href="/patients" class="sidebar-link <?php echo e(request()->is('patients') || request()->is('patients/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">PT</span>
                Patients
            </a>
        <?php endif; ?>

        <?php if(in_array($role, ['Administrator', 'Clinician', 'Lab Technician'])): ?>
            <a href="/viral-load" class="sidebar-link <?php echo e(request()->is('viral-load') || request()->is('viral-load/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">VL</span>
                Viral Load
            </a>
        <?php endif; ?>

        <?php if(in_array($role, ['Administrator', 'Clinician', 'Data Clerk', 'Data Officer', 'Lab Technician'])): ?>
            <a href="<?php echo e(route('samples.index')); ?>" class="sidebar-link <?php echo e(request()->is('samples') || request()->is('samples/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">SM</span>
                Samples
            </a>
        <?php endif; ?>

        <?php if(in_array($role, ['Administrator', 'Clinician'])): ?>
            <a href="/eac" class="sidebar-link <?php echo e(request()->is('eac') || request()->is('eac/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">EA</span>
                EAC Sessions
            </a>
        <?php endif; ?>

        <?php if(in_array($role, ['Administrator', 'Data Clerk', 'Data Officer', 'Receptionist'])): ?>
            <a href="/appointments" class="sidebar-link <?php echo e(request()->is('appointments') || request()->is('appointments/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">AM</span>
                Appointments
            </a>
        <?php endif; ?>

        <?php if($role !== 'Receptionist'): ?>
            <p class="sidebar-section">Insights</p>
        <?php endif; ?>

        <?php if(in_array($role, ['Administrator', 'Receptionist'])): ?>
            <a href="<?php echo e(route('payments.index')); ?>" class="sidebar-link <?php echo e(request()->is('payments') || request()->is('payments/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">PY</span>
                Payments
            </a>
        <?php endif; ?>

        <?php if($role !== 'Receptionist'): ?>
            <a href="/reports" class="sidebar-link <?php echo e(request()->is('reports') || request()->is('reports/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">RP</span>
                Reports
            </a>
        <?php endif; ?>

        <?php if(in_array($role, ['Administrator', 'Clinician'])): ?>
            <a href="<?php echo e(route('ai.assistant.index')); ?>" class="sidebar-link <?php echo e(request()->is('ai-assistant') || request()->is('ai-assistant/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">AI</span>
                AI Assistant
            </a>
        <?php endif; ?>

        <?php if(in_array($role, ['Administrator', 'Clinician'])): ?>
            <p class="sidebar-section">Admin</p>

            <a href="<?php echo e(route('admin.users.index')); ?>" class="sidebar-link <?php echo e(request()->is('admin/users') || request()->is('admin/users/*') ? 'is-active' : ''); ?>">
                <span class="sidebar-icon">US</span>
                User Accounts
            </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        Signed in as <?php echo e($role); ?>

    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>