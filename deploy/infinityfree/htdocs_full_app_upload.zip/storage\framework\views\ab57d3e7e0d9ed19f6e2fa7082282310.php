<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>ViLoCare - <?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></title>

    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('css/theme.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/notification-center.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
<?php ($currentUser = auth()->user()); ?>
<div class="app-shell">
    <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="app-main">
        <nav class="app-topbar">
            <div class="topbar-left">
                <button class="sidebar-toggle" type="button" id="sidebarToggle" aria-label="Toggle navigation">||</button>
                <h1 class="topbar-title"><?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></h1>
            </div>
            <div class="topbar-user">
                <?php echo $__env->make('partials.notification-center', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('topbar_actions'); ?>
                <a href="<?php echo e(route('profile.edit')); ?>" class="user-chip text-decoration-none">
                    <?php if($currentUser && $currentUser->profilePhotoUrl()): ?>
                        <img src="<?php echo e($currentUser->profilePhotoUrl()); ?>" alt="<?php echo e($currentUser->name); ?>" style="width: 28px; height: 28px; border-radius: 999px; object-fit: cover;">
                    <?php else: ?>
                        <span class="user-dot"></span>
                    <?php endif; ?>
                    <?php echo e($currentUser?->name); ?>

                </a>
                <a href="<?php echo e(url('/logout')); ?>" class="btn-logout">Logout</a>
            </div>
        </nav>
        <div class="sidebar-backdrop" id="sidebarBackdrop"></div>
        <main class="app-content container-fluid">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('warning')): ?>
                <div class="alert alert-warning">
                    <?php echo e(session('warning')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0 ps-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    (function () {
        var body = document.body;
        var toggle = document.getElementById('sidebarToggle');
        var backdrop = document.getElementById('sidebarBackdrop');

        if (toggle) {
            toggle.addEventListener('click', function () {
                body.classList.toggle('sidebar-open');
            });
        }

        if (backdrop) {
            backdrop.addEventListener('click', function () {
                body.classList.remove('sidebar-open');
            });
        }

        window.addEventListener('resize', function () {
            if (window.innerWidth > 991) {
                body.classList.remove('sidebar-open');
            }
        });
    })();
</script>
<?php echo $__env->make('partials.sms-compose-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/layouts/app.blade.php ENDPATH**/ ?>