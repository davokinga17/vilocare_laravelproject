<?php $__env->startSection('page_title', 'Appointments'); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/clinical-pages.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="clinical-page">
    <header class="clinical-page-header">
        <div><h2>Appointments</h2><p>Manage patient appointment schedules and reminders.</p></div>
        <div class="clinical-page-actions">
            <?php if(auth()->user()->role !== 'Receptionist'): ?><a href="/appointments/create" class="clinical-btn clinical-btn-primary"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>New Appointment</a><?php endif; ?>
            <button type="button" class="clinical-btn" onclick="window.print()"><svg viewBox="0 0 24 24"><path d="M12 3v12M7 8l5-5 5 5M5 13v7h14v-7"/></svg>Export</button>
        </div>
    </header>

    <?php if(auth()->user()->role === 'Receptionist'): ?><div class="alert alert-info">Receptionist access is view-only. Appointment creation and reminders remain with authorized staff.</div><?php endif; ?>

    <section class="clinical-metrics appointments-metrics">
        <article class="clinical-metric"><span class="clinical-metric-icon">TD</span><div><span>Today</span><strong><?php echo e(number_format($metrics['today'])); ?></strong><small>appointments</small></div></article>
        <article class="clinical-metric"><span class="clinical-metric-icon">UP</span><div><span>Upcoming</span><strong><?php echo e(number_format($metrics['upcoming'])); ?></strong><small>appointments</small></div></article>
        <article class="clinical-metric"><span class="clinical-metric-icon">OK</span><div><span>Completed</span><strong><?php echo e(number_format($metrics['completed'])); ?></strong><small>appointments</small></div></article>
        <article class="clinical-metric"><span class="clinical-metric-icon">MS</span><div><span>Missed</span><strong><?php echo e(number_format($metrics['missed'])); ?></strong><small>appointments</small></div></article>
    </section>

    <form method="GET" action="<?php echo e(route('appointments.index')); ?>" class="clinical-card clinical-toolbar clinical-toolbar-appointments">
        <div class="clinical-field clinical-search"><label for="appointment_search">Search Patient</label><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><input id="appointment_search" name="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="Search by name or ART number..."></div>
        <div class="clinical-field"><label>Date Range</label><div class="clinical-date-pair"><input type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" class="form-control" aria-label="From date"><input type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" class="form-control" aria-label="To date"></div></div>
        <div class="clinical-field"><label for="appointment_purpose">Purpose</label><select id="appointment_purpose" name="purpose" class="form-select"><option value="">All purposes</option><?php $__currentLoopData = $purposes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purpose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($purpose); ?>" <?php if(request('purpose') === $purpose): echo 'selected'; endif; ?>><?php echo e($purpose); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="clinical-field"><label for="appointment_status">Status</label><select id="appointment_status" name="status" class="form-select"><option value="">All statuses</option><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="clinical-toolbar-actions"><button class="clinical-btn clinical-btn-primary">Filter</button><a href="<?php echo e(route('appointments.index')); ?>" class="clinical-btn">Reset</a></div>
    </form>

    <section class="clinical-card clinical-table-card">
        <div class="clinical-table-meta"><strong>Appointment Register</strong><span>Showing <?php echo e($appointments->firstItem() ?? 0); ?>–<?php echo e($appointments->lastItem() ?? 0); ?> of <?php echo e($appointments->total()); ?></span></div>
        <div class="table-responsive">
            <table class="table clinical-table">
                <thead><tr><th>Patient</th><th>ART No.</th><th>Appointment Date</th><th>Purpose</th><th>Facility / Clinic</th><th>Status</th><th>SMS Reminder</th><th>Access</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="primary-cell"><?php echo e($appointment->patient?->first_name); ?> <?php echo e($appointment->patient?->last_name); ?><span class="secondary-line"><?php echo e($appointment->patient?->sex ?: '—'); ?><?php echo e($appointment->patient?->age ? ', '.$appointment->patient->age.' years' : ''); ?></span></td>
                        <td><?php echo e($appointment->patient?->art_number ?: '—'); ?></td>
                        <td class="primary-cell"><?php echo e(optional($appointment->appointment_date)->format('d M Y') ?: '—'); ?></td>
                        <td><?php echo e($appointment->reason ?: 'Routine follow-up'); ?></td>
                        <td><?php echo e($facilityLabels->get($appointment->patient?->facility_id, 'Not assigned')); ?></td>
                        <td><?php ($status = $appointment->status ?: 'Scheduled'); ?><span class="clinical-badge <?php echo e(in_array($status, ['Completed','Confirmed']) ? 'clinical-badge-success' : ($status === 'Missed' || $status === 'Cancelled' ? 'clinical-badge-danger' : 'clinical-badge-warning')); ?>"><?php echo e($status); ?></span></td>
                        <td>
                            <?php if(auth()->user()->role === 'Receptionist'): ?>
                                <span class="clinical-badge clinical-badge-neutral">View only</span>
                            <?php elseif($appointment->status === 'Pending' && in_array(auth()->user()->role, ['Administrator','Clinician'])): ?>
                                <button
                                    type="button"
                                    class="clinical-btn"
                                    data-sms-action="<?php echo e(route('sms.appointments.send', $appointment->appointment_id)); ?>"
                                    data-sms-title="Appointment Reminder"
                                    data-sms-hint="Confirm the patient's number and adjust the appointment reminder before sending."
                                    data-sms-phone="<?php echo e($appointment->patient?->phone); ?>"
                                    data-sms-message="<?php echo e(app(\App\Services\NotificationService::class)->buildAppointmentReminderMessage($appointment)); ?>"
                                >Send SMS</button>
                            <?php else: ?><span class="clinical-badge clinical-badge-success">No action</span><?php endif; ?>
                        </td>
                        <td><span class="clinical-badge <?php echo e(auth()->user()->role === 'Receptionist' ? 'clinical-badge-neutral' : 'clinical-badge-success'); ?>"><?php echo e(auth()->user()->role === 'Receptionist' ? 'Read only' : 'Authorized'); ?></span></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="8" class="clinical-table-empty">No appointments match the selected filters.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="clinical-pagination"><?php echo e($appointments->links()); ?></div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/appointments/index.blade.php ENDPATH**/ ?>