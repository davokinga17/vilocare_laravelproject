<?php $__env->startSection('page_title', 'Payments'); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/payments.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $collectedToday = $paidTodayByCurrency
        ->map(fn ($item) => strtoupper($item->currency) . ' ' . number_format((float) $item->total, 2))
        ->implode(' · ');
    $statusTone = fn (string $status) => match ($status) {
        'paid' => 'is-paid',
        'pending' => 'is-pending',
        'failed' => 'is-failed',
        'cancelled' => 'is-cancelled',
        default => 'is-neutral',
    };
    $methodInitials = fn (string $method) => match ($method) {
        'cash' => 'CA',
        'mtn_momo' => 'MM',
        default => strtoupper(substr($method, 0, 2)),
    };
?>

<div class="payments-page">
    <header class="payments-header">
        <div>
            <span class="payments-eyebrow">Reception · Cashier Desk</span>
            <h2>Payment Requests</h2>
            <p>Review, receive and confirm payments for EAC and patient-result services.</p>
        </div>
        <a href="<?php echo e(route('payments.create')); ?>" class="payments-primary-action">
            <span aria-hidden="true">＋</span> Record Payment
        </a>
    </header>

    <section class="payment-metrics" aria-label="Payment overview">
        <article class="payment-metric metric-pending">
            <span class="metric-icon" aria-hidden="true">⌛</span>
            <div><p>Awaiting Reception</p><strong><?php echo e(number_format($pendingCount)); ?></strong><small>Payment <?php echo e(Str::plural('request', $pendingCount)); ?> requiring action</small></div>
        </article>
        <article class="payment-metric metric-paid">
            <span class="metric-icon" aria-hidden="true">✓</span>
            <div><p>Payments Accepted Today</p><strong><?php echo e(number_format($paidTodayCount)); ?></strong><small>Confirmed since midnight</small></div>
        </article>
        <article class="payment-metric metric-collected">
            <span class="metric-icon" aria-hidden="true">¤</span>
            <div><p>Collected Today</p><strong class="metric-money"><?php echo e($collectedToday ?: 'No collections'); ?></strong><small>Separated by transaction currency</small></div>
        </article>
        <article class="payment-metric metric-total">
            <span class="metric-icon" aria-hidden="true">#</span>
            <div><p>Total Transactions</p><strong><?php echo e(number_format($totalPayments)); ?></strong><small>All recorded payment requests</small></div>
        </article>
    </section>

    <section class="payment-workspace">
        <div class="payment-workspace-head">
            <div><h3>Payment Register</h3><p>Pending requests appear first for faster reception processing.</p></div>
            <span><?php echo e(number_format($payments->total())); ?> <?php echo e(Str::plural('record', $payments->total())); ?></span>
        </div>

        <form method="GET" action="<?php echo e(route('payments.index')); ?>" class="payment-filters">
            <div class="payment-search">
                <label for="search">Find a transaction</label>
                <div><span aria-hidden="true">⌕</span><input id="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Receipt, patient, ART number or service"></div>
            </div>
            <div class="payment-filter-field">
                <label for="payment_type">Service</label>
                <select name="payment_type" id="payment_type">
                    <option value="">All Services</option>
                    <option value="eac_consultation" <?php if(request('payment_type') === 'eac_consultation'): echo 'selected'; endif; ?>>EAC Consultation</option>
                    <option value="result_print" <?php if(request('payment_type') === 'result_print'): echo 'selected'; endif; ?>>Result Print</option>
                    <option value="result_pdf" <?php if(request('payment_type') === 'result_pdf'): echo 'selected'; endif; ?>>Result PDF</option>
                </select>
            </div>
            <div class="payment-filter-field">
                <label for="status">Status</label>
                <select name="status" id="status">
                    <option value="">All Statuses</option>
                    <option value="paid" <?php if(request('status') === 'paid'): echo 'selected'; endif; ?>>Paid</option>
                    <option value="pending" <?php if(request('status') === 'pending'): echo 'selected'; endif; ?>>Pending</option>
                    <option value="failed" <?php if(request('status') === 'failed'): echo 'selected'; endif; ?>>Failed</option>
                    <option value="cancelled" <?php if(request('status') === 'cancelled'): echo 'selected'; endif; ?>>Cancelled</option>
                </select>
            </div>
            <div class="payment-filter-field">
                <label for="payment_method">Method</label>
                <select name="payment_method" id="payment_method">
                    <option value="">All Methods</option>
                    <?php $__currentLoopData = $paymentMethodOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if(request('payment_method') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="payment-filter-actions">
                <button type="submit" class="payment-filter-button"><span aria-hidden="true">▽</span> Apply</button>
                <a href="<?php echo e(route('payments.index')); ?>" class="payment-reset-button"><span aria-hidden="true">↻</span> Reset</a>
            </div>
        </form>

        <div class="payment-table-wrap">
            <table class="payment-table">
                <thead>
                    <tr>
                        <th>Receipt</th>
                        <th>Patient</th>
                        <th>Service</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Status</th>
                        <th>Requested By</th>
                        <th>Paid At</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($payment->status === 'pending' ? 'is-priority-row' : ''); ?>">
                            <td><a class="receipt-link" href="<?php echo e(route('payments.show', $payment->payment_id)); ?>"><?php echo e($payment->receipt_number); ?></a></td>
                            <td>
                                <?php if($payment->patient): ?>
                                    <div class="patient-cell">
                                        <span><?php echo e(strtoupper(substr($payment->patient->first_name, 0, 1) . substr($payment->patient->last_name, 0, 1))); ?></span>
                                        <div><strong><?php echo e($payment->patient->first_name); ?> <?php echo e($payment->patient->last_name); ?></strong><small><?php echo e($payment->patient->art_number ?: 'No ART number'); ?></small></div>
                                    </div>
                                <?php else: ?>
                                    <span class="cell-muted">Unknown patient</span>
                                <?php endif; ?>
                            </td>
                            <td><strong class="service-name"><?php echo e($payment->service_label); ?></strong></td>
                            <td><strong class="payment-amount"><?php echo e($payment->currency); ?> <?php echo e(number_format((float) $payment->amount, 2)); ?></strong></td>
                            <td><span class="method-cell"><span><?php echo e($methodInitials($payment->payment_method)); ?></span><?php echo e($paymentMethodOptions[$payment->payment_method] ?? strtoupper(str_replace('_', ' ', $payment->payment_method))); ?></span></td>
                            <td><span class="payment-status <?php echo e($statusTone($payment->status)); ?>"><i></i><?php echo e(ucfirst($payment->status)); ?></span></td>
                            <td><span class="requester-name"><?php echo e($payment->creator?->name ?: 'System'); ?></span></td>
                            <td>
                                <?php if($payment->paid_at): ?>
                                    <span class="payment-date"><?php echo e($payment->paid_at->format('d M Y')); ?><small><?php echo e($payment->paid_at->format('H:i')); ?></small></span>
                                <?php else: ?>
                                    <span class="cell-muted">Not yet paid</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="payment-row-actions">
                                    <?php if($payment->status === 'pending'): ?>
                                        <form method="POST" action="<?php echo e(route('payments.accept_cash', $payment)); ?>" onsubmit="return confirm('Confirm that cash was received for this service?')">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="accept-cash-button"><span aria-hidden="true">✓</span> Accept Cash</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if($payment->payment_method === 'mtn_momo' && in_array($payment->status, ['failed', 'cancelled'], true)): ?>
                                        <form method="POST" action="<?php echo e(route('payments.retry', $payment->payment_id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="retry-payment-button">Retry</button>
                                        </form>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('payments.show', $payment->payment_id)); ?>" class="view-payment-button" aria-label="View payment <?php echo e($payment->receipt_number); ?>">View</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="9"><div class="payment-empty"><span aria-hidden="true">¤</span><strong>No payments found</strong><p>Try adjusting the filters or record a new payment.</p></div></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($payments->hasPages()): ?>
            <div class="payment-pagination"><?php echo e($payments->onEachSide(1)->links('pagination::bootstrap-5')); ?></div>
        <?php endif; ?>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\vilocare_laravelproject\vilocare_laravelproject\resources\views/payments/index.blade.php ENDPATH**/ ?>